#ifndef REDIST_ANALYSIS_H
#define REDIST_ANALYSIS_H

Rcpp::NumericVector segregationcalc(Rcpp::NumericMatrix distmat,
				    Rcpp::NumericVector grouppop,
				    Rcpp::NumericVector fullpop);
#endif

